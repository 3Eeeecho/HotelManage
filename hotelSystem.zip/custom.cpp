#include "custom.h"
#include "ui_custom.h"

Custom::Custom(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Custom)
{
    ui->setupUi(this);

    QObject::disconnect(ui->customManageButton, nullptr, this, nullptr);
    QObject::disconnect(ui->customAddButton, nullptr, this, nullptr);
    QObject::disconnect(ui->SelectButton, nullptr, this, nullptr);
    QObject::disconnect(ui->addIndividualButton, nullptr, this, nullptr);
    QObject::disconnect(ui->backHomeButton, nullptr, this, nullptr);
    QObject::disconnect(ui->DeleteButton, nullptr, this, nullptr);
    QObject::disconnect(ui->addTeamButton, nullptr, this, nullptr);

    //转到客户查询界面
    connect(ui->customManageButton,&QPushButton::clicked,this,&Custom::on_customManageButton_clicked);

    //转到添加客户界面
    connect(ui->customAddButton,&QPushButton::clicked,this,&Custom::on_customAddButton_clicked);

    //转到添加团队界面
    connect(ui->teamAddButton,&QPushButton::clicked,this,&Custom::on_teamAddButton_clicked);

    //查询客户信息
    connect(ui->SelectButton,&QPushButton::clicked,this,&Custom::on_SelectButton_clicked);

    //删除客户信息
    connect(ui->DeleteButton,&QPushButton::clicked,this,&Custom::on_DeleteButton_clicked);

    //添加个人客户
    connect(ui->addIndividualButton,&QPushButton::clicked,this,&Custom::on_addIndividualButton_clicked);

    //添加团队
    connect(ui->addTeamButton,&QPushButton::clicked,this,&Custom::on_addTeamButton_clicked);

    // 连接返回按钮
    connect(ui->backHomeButton, &QPushButton::clicked, [=, this](){emit this->backHome();});
}

void Custom::setInitialPage()
{
    ui->stackedWidget->setCurrentIndex(0);
}

Custom::~Custom()
{
    delete ui;
}

QList<individual> Custom::getIndividual(QString name, QString id,QString phone)
{
    QSqlQuery query;
    QString queryString = "SELECT * FROM client WHERE 1=1";

    if (!name.isEmpty()) {
        queryString += QString(" AND cname LIKE '%%1%'").arg(name);
    }

    if (!phone.isEmpty()) {
        queryString += QString(" AND cphone LIKE '%%1%'").arg(phone);
    }

    if (!id.isEmpty()) {
        queryString += QString(" AND cid = '%1'").arg(id);
    }

    query.prepare(queryString);

    if (!query.exec()) {
        qDebug() << "Query execution error:" << query.lastError().text();
        return QList<individual>();
    }

    QList<individual> individuals;
    while (query.next()) {
        individual ind;
        ind.m_name = query.value("cname").toString();
        ind.m_id = query.value("cid").toString();
        ind.m_phone = query.value("cphone").toString();
        ind.m_age = query.value("cage").toString();
        ind.m_sex = query.value("csex").toString();
        ind.m_registerId = query.value("register_sid").toString();
        ind.m_registerTime = query.value("register_time").toString();
        individuals.append(ind);
    }

    return individuals;
}

QList<team> Custom::getTeam(QString name, QString id,QString phone)
{
    QSqlQuery query;
    QString queryString = "SELECT * FROM team WHERE 1=1";

    if (!name.isEmpty()) {
        queryString += QString(" AND tname LIKE '%%1%'").arg(name);
    }

    if (!id.isEmpty()) {
        queryString += QString(" AND tid = '%1'").arg(id);
    }

    if (!phone.isEmpty()) {
        queryString += QString(" AND tphone LIKE '%%1%'").arg(phone);
    }


    query.prepare(queryString);

    if (!query.exec()) {
        qDebug() << "Query execution error:" << query.lastError().text();
        return QList<team>();
    }

    QList<team> teams;
    while (query.next()) {
        team tm;
        tm.m_name = query.value("tname").toString();
        tm.m_id = query.value("tid").toString();
        tm.m_phone = query.value("tphone").toString();
        tm.m_registerId = query.value("check_in_sid").toString();
        tm.m_registerTime = query.value("register_time").toString();
        teams.append(tm);
    }

    return teams;
}

void Custom::on_SelectButton_clicked()
{
    QString name = ui->customNameLineEdit->text();
    QString phone = ui->customPhoneLineEdit->text();
    QString id= ui->customIdLineEdit->text();
    QString type = ui->typeBox->currentText();

    if (type == "个人") {
        ui->TablestackedWidget->setCurrentIndex(0);
        QList<individual> individuals = getIndividual(name, id, phone);
        ui->individualTableWidget->setRowCount(0); // 清空表格

        if (individuals.isEmpty()) {
            int row = ui->individualTableWidget->rowCount();
            ui->individualTableWidget->insertRow(row);
            QTableWidgetItem *item = new QTableWidgetItem("未找到指定信息");
            item->setTextAlignment(Qt::AlignCenter);
            ui->individualTableWidget->setItem(row, 0, item);
            ui->individualTableWidget->setSpan(row, 0, 1, ui->individualTableWidget->columnCount()); // 跨列显示
        } else {
            for (const individual &ind : individuals) {
                int row = ui->individualTableWidget->rowCount();
                ui->individualTableWidget->insertRow(row);
                ui->individualTableWidget->setItem(row, 0, new QTableWidgetItem(ind.m_name));
                ui->individualTableWidget->setItem(row, 1, new QTableWidgetItem(ind.m_id));
                ui->individualTableWidget->setItem(row, 2, new QTableWidgetItem(ind.m_phone));
                ui->individualTableWidget->setItem(row, 3, new QTableWidgetItem(ind.m_age));
                ui->individualTableWidget->setItem(row, 4, new QTableWidgetItem(ind.m_sex));
                ui->individualTableWidget->setItem(row, 5, new QTableWidgetItem(ind.m_registerId));
                ui->individualTableWidget->setItem(row, 6, new QTableWidgetItem(ind.m_registerTime));
            }
        }
    } else if (type == "团队") {
        ui->TablestackedWidget->setCurrentIndex(1);
        QList<team> teams = getTeam(name, id, phone);
        ui->teamTableWidget->setRowCount(0); // 清空表格

        if (teams.isEmpty()) {
            int row = ui->teamTableWidget->rowCount();
            ui->teamTableWidget->insertRow(row);
            QTableWidgetItem *item = new QTableWidgetItem("未找到指定信息");
            item->setTextAlignment(Qt::AlignCenter);
            ui->teamTableWidget->setItem(row, 0, item);
            ui->teamTableWidget->setSpan(row, 0, 1, ui->teamTableWidget->columnCount()); // 跨列显示
        } else {
            for (const team &tm : teams) {
                int row = ui->teamTableWidget->rowCount();
                ui->teamTableWidget->insertRow(row);
                ui->teamTableWidget->setItem(row, 0, new QTableWidgetItem(tm.m_name));
                ui->teamTableWidget->setItem(row, 1, new QTableWidgetItem(tm.m_id));
                ui->teamTableWidget->setItem(row, 2, new QTableWidgetItem(tm.m_phone));
                ui->teamTableWidget->setItem(row, 3, new QTableWidgetItem(tm.m_registerId));
                ui->teamTableWidget->setItem(row, 4, new QTableWidgetItem(tm.m_registerTime));
            }
        }
    }
}

void Custom::on_DeleteButton_clicked()
{
    QString name = ui->customNameLineEdit->text();
    QString phone = ui->customPhoneLineEdit->text();
    QString id = ui->customIdLineEdit->text();
    QString type = ui->typeBox->currentText();

    // 检查是否提供了至少一个有效参数
    if (name.isEmpty() && phone.isEmpty() && id.isEmpty()) {
        QMessageBox::warning(this, "删除失败", "请提供至少一个有效的删除参数（姓名、手机号、ID）。");
        return;
    }

    // 提供弹窗，选择是否要删除还是取消
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "确认删除", "确定要删除这个客户吗？",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {

        // 删除数据库中的记录
        QSqlQuery query;
        QString queryString;
        if (type == "个人") {
            QString queryString = "DELETE FROM client WHERE 1=1";
            if (!name.isEmpty()) {
                queryString += QString(" AND cname = '%1'").arg(name);
            }
            if (!phone.isEmpty()) {
                queryString += QString(" AND cphone = '%1'").arg(phone);
            }
            if (!id.isEmpty()) {
                queryString += QString(" AND cid = '%1'").arg(id);
            }
        }
        else{
            queryString = "DELETE FROM team WHERE 1=1";
            if (!name.isEmpty()) {
                queryString += QString(" AND tname = '%1'").arg(name);
            }
            if (!phone.isEmpty()) {
                queryString += QString(" AND tphone = '%1'").arg(phone);
            }
            if (!id.isEmpty()) {
                queryString += QString(" AND tid = '%1'").arg(id);
            }
        }
        qDebug() << "Constructed Query for deletion:" << queryString;
        query.prepare(queryString);

        if (!query.exec()) {
            qDebug() << "Delete error:" << query.lastError().text();
            QMessageBox::critical(this, "数据库错误", "无法删除客户信息，请稍后再试。");
            return;
        }

        // 清空输入框
        ui->customNameLineEdit->clear();
        ui->customPhoneLineEdit->clear();
        ui->customIdLineEdit->clear();
        ui->typeBox->setCurrentIndex(0);

        // 提示删除成功
        QMessageBox::information(this, "删除成功", "客户信息删除成功。");
    } else {
        // 用户选择取消
        QMessageBox::information(this, "取消操作", "客户信息删除操作已取消。");
    }
}

void Custom::on_addIndividualButton_clicked()
{
    // 从用户输入获取信息
    QString name = ui->addCNameLineEdit->text();
    QString id = ui->addCIdLIneEdit->text();
    QString phone = ui->addCPhoneLineEdit->text();
    QString age = ui->addCAgeLineEdit->text();
    QString sex = ui->addCSexBox->currentText();
    QString registerId = ui->addCRidLineEdit->text();
    QString registerTime = ui->addCTimeLineEdit->text();

    // 检查输入是否为空
    if (name.isEmpty() || id.isEmpty()  || age.isEmpty() ) {
        QMessageBox::warning(this, "输入错误", "请填写完必要信息。");
        return;
    }

    // 插入到数据库
    QSqlQuery query;
    query.prepare("INSERT INTO client (cname, cid, cphone, cage, csex, register_sid, register_time) "
                  "VALUES (:name, :id, :phone, :age, :sex, :registerId, :registerTime)");
    query.bindValue(":name", name);
    query.bindValue(":id", id);
    query.bindValue(":phone", phone);
    query.bindValue(":age", age);
    query.bindValue(":sex", sex);
    query.bindValue(":registerId", registerId);
    query.bindValue(":registerTime", registerTime);

    if (!query.exec()) {
        qDebug() << "Insert error:" << query.lastError().text();
        QMessageBox::critical(this, "数据库错误", "无法添加个人客户信息，请稍后再试。");
        return;
    }

    // 清空输入框
    ui->addCNameLineEdit->clear();
    ui->addCIdLIneEdit->clear();
    ui->addCPhoneLineEdit->clear();
    ui->addCAgeLineEdit->clear();
    ui->addCSexBox->setCurrentIndex(0);
    ui->addCRidLineEdit->clear();
    ui->addCTimeLineEdit->clear();

    QMessageBox::information(this, "成功", "个人客户信息添加成功。");
}

void Custom::on_addTeamButton_clicked()
{
    // 从用户输入获取信息
    QString name = ui->addTNameLineEdit->text();
    QString id = ui->addTIdLineEdit->text();
    QString phone = ui->addTPhoneLineEdit->text();
    QString registerId = ui->addTRidLineEdit->text();
    QString registerTime = ui->addTtimeLineEdit->text();

    // 检查输入是否为空
    if (name.isEmpty() || id.isEmpty() ) {
        QMessageBox::warning(this, "输入错误", "请填写完必要信息。");
        return;
    }

    // 插入到数据库
    QSqlQuery query;
    query.prepare("INSERT INTO team (tname, tid, tphone, check_in_sid, register_time) "
                  "VALUES (:name, :id, :phone, :registerId, :registerTime)");
    query.bindValue(":name", name);
    query.bindValue(":id", id);
    query.bindValue(":phone", phone);
    query.bindValue(":registerId", registerId);
    query.bindValue(":registerTime", registerTime);

    if (!query.exec()) {
        qDebug() << "Insert error:" << query.lastError().text();
        QMessageBox::critical(this, "数据库错误", "无法添加团队信息，请稍后再试。");
        return;
    }

    // 清空输入框
    ui->addTNameLineEdit->clear();
    ui->addTIdLineEdit->clear();
    ui->addTPhoneLineEdit->clear();
    ui->addTRidLineEdit->clear();
    ui->addTtimeLineEdit->clear();

    QMessageBox::information(this, "成功", "团队信息添加成功。");
}

void Custom::on_customManageButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void Custom::on_customAddButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
    ui->addStackedWidget->setCurrentIndex(0);
}

void Custom::on_teamAddButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
    ui->addStackedWidget->setCurrentIndex(1);
}




