#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include "home.h"
#include "aboutus.h"

namespace Ui {
class Login;
}

class Login : public QWidget
{
    Q_OBJECT

public:
    explicit Login(QWidget *parent = nullptr);
    ~Login();

private slots:
    void on_loginButton_clicked();

    void on_aboutUsButton_clicked();

private:
    Ui::Login *ui;
    Home homeUi;
    AboutUs about;
    QSqlDatabase db;
};

#endif // LOGIN_H
