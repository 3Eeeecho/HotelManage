#ifndef HOTELSYS_H
#define HOTELSYS_H

#include <QObject>
#include <QSqlDatabase>
#include "login.h"

class hotelsys : public QObject
{
    Q_OBJECT

public:
    explicit hotelsys(QObject *parent = nullptr);
    ~hotelsys();

private slots:
    void onLoginSuccess();

private:
    Login *loginUi;
    QSqlDatabase db;
};

#endif // HOTELSYS_H
