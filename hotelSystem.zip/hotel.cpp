#include "hotel.h"

Hotel::Hotel(QObject *parent)
    : QObject{parent}
{

}

//获取客房信息
QList<room> Hotel::getRoom(QString roomid, QString type, double leastPrice, double mostPrice, QString status)
{
    if (leastPrice > mostPrice) {
        qDebug() << "Invalid price range: leastPrice should be less than or equal to mostPrice";
        return QList<room>();
    }

    QSqlQuery sql(db);
    QString queryString = "SELECT * FROM room WHERE 1=1";

    if (!roomid.isEmpty()) {
        queryString += QString(" AND rid = %1").arg(roomid);
    }

    if (!type.isEmpty()&&type!="所有") {
        queryString += QString(" AND rtype = '%1'").arg(type);
    }

    if (leastPrice > 0) {
        queryString += QString(" AND rprice >= %1").arg(leastPrice);
    }

    if (mostPrice > 0) {
        queryString += QString(" AND rprice <= %1").arg(mostPrice);
    }

    if (!status.isEmpty()&&status!="所有") {
        queryString += QString(" AND rstatus = '%1'").arg(status);
    }

    qDebug() << "Constructed Query:" << queryString;
    sql.prepare(queryString);

    if (!sql.exec()) {
        qDebug() << "Query execution error:" << sql.lastError().text();
        return QList<room>();
    }

    QList<room> rooms;
    while (sql.next()) {
        room r;
        r.m_roomId = sql.value("rid").toString();   
        r.m_type = sql.value("rtype").toString();
        r.m_size = sql.value("rsize").toUInt();
        r.m_price = sql.value("rprice").toDouble();
        r.m_status = sql.value("rstatus").toString();
        rooms.append(r);
    }

    if (rooms.isEmpty()) {
        qDebug() << "No results found.";
    }

    return rooms;
}
