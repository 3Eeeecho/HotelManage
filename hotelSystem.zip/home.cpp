#include "home.h"
#include "ui_home.h"

Home::Home(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Home)
{
    ui->setupUi(this);
    QObject::disconnect(ui->staffButton, nullptr, this, nullptr);

    //等待客房界面返回信号
    room = new Room;
    connect(room,&Room::backHome,this,[=, this](){
        room->close();
        this->show();
    });

    //等待客户界面返回信号
    custom = new Custom;
    connect(custom,&Custom::backHome,this,[=, this](){
        custom->close();
        this->show();
    });

    //等待员工界面返回主页信号
    staff = new Staff;
    connect(staff,&Staff::backHome,this,[=, this](){
        staff->close();
        this->show();
    });

    //等待员工界面返回主页信号
    order = new Order;
    connect(order,&Order::backHome,this,[=, this](){
        order->close();
        this->show();
    });

    connect(ui->roomButton, &QPushButton::clicked, this, &Home::on_roomButton_clicked);
    connect(ui->customButton, &QPushButton::clicked, this, &Home::on_customButton_clicked);
    connect(ui->staffButton, &QPushButton::clicked, this, &Home::on_staffButton_clicked);
    connect(ui->orderButton, &QPushButton::clicked, this, &Home::on_orderButton_clicked);

    // 连接退出登录按钮
    connect(ui->exitButton, &QPushButton::clicked, [=, this](){emit this->exit();});
}

void Home::setUserRole(const QString &role)
{
    currentUserRole = role;
}


Home::~Home()
{
    delete ui;
}

void Home::on_roomButton_clicked()
{
    this->close();
    room->show();
    room->setInitialPage();
}


void Home::on_customButton_clicked()
{
    this->close();
    custom->show();
    custom->setInitialPage();
}


void Home::on_staffButton_clicked()
{
    // 检查当前用户的角色
    if (currentUserRole != "root") {
        // 显示警告消息
        QMessageBox::warning(this, "权限不足", "您没有权限访问此功能。");
        return;
    }

    // 如果是root用户，执行以下操作
    this->close();
    staff->show();
    staff->setInitialPage();
}


void Home::on_orderButton_clicked()
{
    this->close();
    order->show();
    order->setInitialPage();
}

