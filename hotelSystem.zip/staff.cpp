#include "staff.h"
#include "ui_staff.h"

Staff::Staff(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Staff)
{
    ui->setupUi(this);

    QObject::disconnect(ui->selectStaffButton, nullptr, this, nullptr);
    QObject::disconnect(ui->addStaffButton, nullptr, this, nullptr);
    QObject::disconnect(ui->staffSelectButton, nullptr, this, nullptr);
    QObject::disconnect(ui->staffDeleteButton, nullptr, this, nullptr);
    QObject::disconnect(ui->backHomeButton, nullptr, this, nullptr);

    //转到查询员工页面
    connect(ui->selectStaffButton,&QPushButton::clicked,this,&Staff::on_selectStaffButton_clicked);

    //转到添加员工界面
    connect(ui->addStaffButton,&QPushButton::clicked,this,&Staff::on_addStaffButton_clicked);

    //查询员工
    connect(ui->staffSelectButton,&QPushButton::clicked,this,&Staff::on_staffSelectButton_clicked);

    //删除员工
    connect(ui->staffDeleteButton,&QPushButton::clicked,this,&Staff::on_staffDeleteButton_clicked);

    // 连接返回按钮
    connect(ui->backHomeButton, &QPushButton::clicked, [=, this](){emit this->backHome();});

}

void Staff::setInitialPage()
{
    ui->staffStackedWidget->setCurrentIndex(0);
}

Staff::~Staff()
{
    delete ui;
}

void Staff::on_selectStaffButton_clicked()
{
    ui->staffStackedWidget->setCurrentIndex(0);
}

void Staff::on_addStaffButton_clicked()
{
    ui->staffStackedWidget->setCurrentIndex(1);
}

QList<staff> Staff::getStaff(QString id,QString name,QString role)
{
    QSqlQuery query;
    QString queryString = "SELECT * FROM staff WHERE 1=1";

    if (!id.isEmpty()) {
        queryString += QString(" AND sid = '%1'").arg(id);
    }

    if (!name.isEmpty()) {
        queryString += QString(" AND sname LIKE '%%1%'").arg(name);
    }

    if (!role.isEmpty()) {
        queryString += QString(" AND srole = '%1'").arg(role);
    }

    query.prepare(queryString);

    if (!query.exec()) {
        qDebug() << "Query execution error:" << query.lastError().text();
        return QList<staff>();
    }

    QList<staff> staffs;
    while (query.next()) {
        staff s;
        s.m_id = query.value("sid").toString();
        s.m_name = query.value("sname").toString();
        s.m_sex = query.value("ssex").toString();
        s.m_username = query.value("susername").toString();
        s.m_password = query.value("spassword").toString();
        s.m_role = query.value("srole").toString();
        staffs.append(s);
    }

    return staffs;
}

void Staff::on_staffSelectButton_clicked()
{
    QString id= ui->staffIdLineEdit->text();
    QString name = ui->staffNameLineEdit->text();
    QString role = ui->staffRoleLineEdit->text();

        QList<staff> staffs = getStaff(id, name, role);
        ui->staffTableWidget->setRowCount(0); // 清空表格

        if (staffs.isEmpty()) {
            int row = ui->staffTableWidget->rowCount();
            ui->staffTableWidget->insertRow(row);
            QTableWidgetItem *item = new QTableWidgetItem("未找到指定信息");
            item->setTextAlignment(Qt::AlignCenter);
            ui->staffTableWidget->setItem(row, 0, item);
            ui->staffTableWidget->setSpan(row, 0, 1, ui->staffTableWidget->columnCount()); // 跨列显示
        } else {
            for (const staff &s : staffs) {
                int row = ui->staffTableWidget->rowCount();
                ui->staffTableWidget->insertRow(row);
                ui->staffTableWidget->setItem(row, 0, new QTableWidgetItem(s.m_id));
                ui->staffTableWidget->setItem(row, 1, new QTableWidgetItem(s.m_name));
                ui->staffTableWidget->setItem(row, 2, new QTableWidgetItem(s.m_sex));
                ui->staffTableWidget->setItem(row, 3, new QTableWidgetItem(s.m_username));
                ui->staffTableWidget->setItem(row, 4, new QTableWidgetItem(s.m_password));
                ui->staffTableWidget->setItem(row, 5, new QTableWidgetItem(s.m_role));
            }
        }

}


void Staff::on_staffDeleteButton_clicked()
{
    QString id = ui->staffIdLineEdit->text();
    QString name = ui->staffNameLineEdit->text();
    QString role = ui->staffRoleLineEdit->text();

    // 检查是否提供了至少一个有效参数
    if (name.isEmpty() && role.isEmpty() && id.isEmpty()) {
        QMessageBox::warning(this, "删除失败", "请提供至少一个有效的删除参数（姓名、权限等级、ID）。");
        return;
    }

    // 提供弹窗，选择是否要删除还是取消
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "确认删除", "确定要删除这个员工吗？",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {

        // 获取username
        QString username;
        QSqlQuery query;
        QString queryString = "SELECT susername FROM staff WHERE 1=1";

        if (!name.isEmpty()) {
            queryString += QString(" AND sname = '%1'").arg(name);
        }
        if (!role.isEmpty()) {
            queryString += QString(" AND srole = '%1'").arg(role);
        }
        if (!id.isEmpty()) {
            queryString += QString(" AND sid = '%1'").arg(id);
        }

        qDebug() << "Constructed Query to find username:" << queryString;
        query.prepare(queryString);

        if (!query.exec()) {
            qDebug() << "Error finding username:" << query.lastError().text();
            QMessageBox::critical(this, "数据库错误", "无法获取用户信息，请稍后再试。");
            return;
        }

        if (query.next()) {
            username = query.value(0).toString();
        } else {
            QMessageBox::warning(this, "删除失败", "未找到符合条件的用户。");
            return;
        }

        // 删除数据库中的记录
        queryString = "DELETE FROM staff WHERE 1=1";
        if (!name.isEmpty()) {
            queryString += QString(" AND sname = '%1'").arg(name);
        }
        if (!role.isEmpty()) {
            queryString += QString(" AND srole = '%1'").arg(role);
        }
        if (!id.isEmpty()) {
            queryString += QString(" AND sid = '%1'").arg(id);
        }

        qDebug() << "Constructed Query for deletion:" << queryString;
        query.prepare(queryString);

        if (!query.exec()) {
            qDebug() << "Delete error:" << query.lastError().text();
            QMessageBox::critical(this, "数据库错误", "无法删除客户信息，请稍后再试。");
            return;
        }

        // 删除MySQL用户
        queryString = QString("DROP USER '%1'@'%'").arg(username);
        qDebug() << "Constructed Query to drop user:" << queryString;
        query.prepare(queryString);

        if (!query.exec()) {
            qDebug() << "Drop user error:" << query.lastError().text();
            QMessageBox::critical(this, "数据库错误", "无法删除MySQL用户，请稍后再试。");
            return;
        }

        // 清空输入框
        ui->staffIdLineEdit->clear();
        ui->staffNameLineEdit->clear();
        ui->staffRoleLineEdit->clear();

        // 提示删除成功
        QMessageBox::information(this, "删除成功", "员工信息和MySQL用户删除成功。");
    } else {
        // 用户选择取消
        QMessageBox::information(this, "取消操作", "员工信息删除操作已取消。");
    }
}


void Staff::on_staffAddButton_clicked()
{
    // 从用户输入获取信息
    QString id = ui->addStaffIdineEdit->text();
    QString name = ui->addStaffNameLineEdit->text();
    QString sex = ui->addStaffSexBox->currentText();
    QString username = ui->addStaffUserLineEdit->text();
    QString password = ui->addStaffPwLineEdit->text();
    QString role = ui->addStaffRoleLineEdit->text();

    // 检查输入是否为空
    if (name.isEmpty() || id.isEmpty()  || username.isEmpty() || password.isEmpty() || role.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请填写必要信息。");
        return;
    }

    // 根据role创建系统用户并赋予权限
    if (!createSystemUser(username, password, role)) {
        QMessageBox::critical(this, "系统错误", "无法创建系统用户，请联系管理员。");
        return;
    }

    // 插入到数据库
    QSqlQuery query;
    query.prepare("INSERT INTO staff (sid, sname, ssex, susername, spassword, srole) "
                  "VALUES (:id, :name, :sex, :username, :password, :role)");
    query.bindValue(":id", id);
    query.bindValue(":name", name);
    query.bindValue(":sex", sex);
    query.bindValue(":username", username);
    query.bindValue(":password", password);
    query.bindValue(":role", role);

    if (!query.exec()) {
        qDebug() << "Insert error:" << query.lastError().text();
        QMessageBox::critical(this, "数据库错误", "无法添加员工信息，请稍后再试。");
        return;
    }

    // 清空输入框
    ui->addStaffIdineEdit->clear();
    ui->addStaffNameLineEdit->clear();
    ui->addStaffSexBox->setCurrentIndex(0);
    ui->addStaffUserLineEdit->clear();
    ui->addStaffPwLineEdit->clear();
    ui->addStaffRoleLineEdit->clear();

    QMessageBox::information(this, "成功", "员工信息添加成功。");
}

bool Staff::createSystemUser(const QString &username, const QString &password, const QString &role)
{
    QSqlQuery query;
    QString queryString1;
    QString queryString2;
    if (role == "1") {
        // 创建用户并赋予Level1_Staff权限
        queryString1 = QString("CREATE USER '%1' @'%' IDENTIFIED BY '%2'")
                      .arg(username).arg(password);
        queryString2 = QString("GRANT Level1_Staff TO '%1' @'%'")
                           .arg(username);
    } else if (role == "2") {
        // 创建用户并赋予Level2_Staff权限
        queryString1 = QString("CREATE USER '%1' @'%' IDENTIFIED BY '%2'")
                      .arg(username).arg(password);
        queryString2 = QString("GRANT Level2_Staff TO '%1' @'%'")
                           .arg(username);
    } else {
        qDebug() << "未知角色:" << role;
        return false;
    }

    query.prepare(queryString1);

    if (!query.exec()) {
        qDebug() << "Query execution error:" << query.lastError().text();
        return false;
    }

    query.prepare(queryString2);

    if (!query.exec()) {
        qDebug() << "Query execution error:" << query.lastError().text();
        return false;
    }

    QString queryString = "FLUSH PRIVILEGES";
    query.prepare(queryString);

    queryString = "SET global activate_all_roles_on_login = ON";
    query.prepare(queryString);

    return true;
}

