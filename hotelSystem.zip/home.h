#ifndef HOME_H
#define HOME_H

#include <QWidget>
#include "room.h"
#include "custom.h"
#include "staff.h"
#include "order.h"

namespace Ui {
class Home;
}

class Home : public QWidget
{
    Q_OBJECT

public:
    explicit Home(QWidget *parent = nullptr);
    void setUserRole(const QString &role);
    ~Home();


signals:
    void exit();

private slots:

    void on_roomButton_clicked();

    void on_customButton_clicked();

    void on_staffButton_clicked();

    void on_orderButton_clicked();

private:
    Ui::Home *ui;
    Room *room;
    Custom *custom;
    Staff *staff;
    Order *order;
    QString currentUserRole;
};

#endif // HOME_H
