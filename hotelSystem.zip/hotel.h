#ifndef HOTEL_H
#define HOTEL_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>



struct room
{
    QString m_roomId;
    QString m_type;
    quint8 m_size;
    double m_price;
    QString m_status;
};
class Hotel : public QObject
{
    Q_OBJECT
public:
    explicit Hotel(QObject *parent = nullptr);

    //查询客房信息
    QList<room> getRoom(QString roomid,QString type,double leastPrice,double mostPrice,QString status);
signals:

private:
    QSqlDatabase db;
};

#endif // HOTEL_H
