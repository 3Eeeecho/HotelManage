#include "room.h"
#include "ui_room.h"

Room::Room(QWidget *parent,Home *home)
    : QWidget(parent)
    , ui(new Ui::Room)
    ,home(home)
{
    ui->setupUi(this);

    // 确保信号槽只连接一次
    QObject::disconnect(ui->roomInforButton, nullptr, this, nullptr);
    QObject::disconnect(ui->roomselectButton, nullptr, this, nullptr);
    QObject::disconnect(ui->addRoomButton, nullptr, this, nullptr);
    QObject::disconnect(ui->roomDeleteButton, nullptr, this, nullptr);

    QObject::disconnect(ui->backHomeButton, nullptr, this, nullptr);

    //转到客房查询页面
    connect(ui->roomInforButton,&QPushButton::clicked,this,&Room::on_roomInforButton_clicked);
    //转到添加客房页面
    connect(ui->roomAddButton,&QPushButton::clicked,this,&Room::on_roomAddButton_clicked);
    //查询客房信息
    connect(ui->roomselectButton,&QPushButton::clicked,this,&Room::on_roomselectButton_clicked);
    //添加客房信息
    connect(ui->addRoomButton,&QPushButton::clicked,this,&Room::on_addRoomButton_clicked);
    //删除客房信息
    connect(ui->roomDeleteButton,&QPushButton::clicked,this,&Room::on_roomDeleteButton_clicked);



    // 连接返回按钮
    connect(ui->backHomeButton, &QPushButton::clicked, [=, this](){emit this->backHome();});
}

void Room::setInitialPage()
{
    ui->stackedWidget->setCurrentIndex(0);
}

Room::~Room()
{
    delete ui;
}

void Room::on_roomInforButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void Room::on_roomselectButton_clicked()
{
    QString roomid = ui->roomidLineEdit->text();
    QString type = ui->typeBox->currentText();
    QString leastPrice = ui->leastLineEdit->text();
    QString mostPrice = ui->mostLineEdit->text();
    QString status = ui->statusBox->currentText();

    double leastPriceDouble=leastPrice.isEmpty() ? 0 : leastPrice.toDouble();
    double mostPriceDouble=mostPrice.isEmpty() ? 0 : mostPrice.toDouble();

    QList<room> rooms = hotel.getRoom(roomid, type, leastPriceDouble, mostPriceDouble, status);

    ui->roomTableWidget->setRowCount(0); // 清空表格

    if (rooms.isEmpty()) {
        int row = ui->roomTableWidget->rowCount();
        ui->roomTableWidget->insertRow(row);
        QTableWidgetItem *item = new QTableWidgetItem("未找到指定信息");
        item->setTextAlignment(Qt::AlignCenter);
        ui->roomTableWidget->setItem(row, 0, item);
        ui->roomTableWidget->setSpan(row, 0, 1, ui->roomTableWidget->columnCount()); // 跨列显示
    } else {
        for (const room &r : rooms) {
            int row = ui->roomTableWidget->rowCount();
            ui->roomTableWidget->insertRow(row);
            ui->roomTableWidget->setItem(row, 0, new QTableWidgetItem(r.m_roomId));
            ui->roomTableWidget->setItem(row, 1, new QTableWidgetItem(r.m_type));
            ui->roomTableWidget->setItem(row, 2, new QTableWidgetItem(QString::number(r.m_size)));
            ui->roomTableWidget->setItem(row, 3, new QTableWidgetItem(QString::number(r.m_price)));
            ui->roomTableWidget->setItem(row, 4, new QTableWidgetItem(r.m_status));
        }
    }

}


void Room::on_addRoomButton_clicked()
{
    // 从用户输入获取信息
    QString roomId = ui->addRIdLineEdit->text();
    QString type = ui->typeBox_2->currentText();
    QString sizeStr = ui->addRsizeLineEdit->text();
    QString priceStr = ui->addRpriceLineEdit->text();
    QString status = ui->statusBox_2->currentText();

    // 转换 size 和 price 为数字类型
    bool sizeOk, priceOk;
    int size = sizeStr.toInt(&sizeOk);
    double price = priceStr.toDouble(&priceOk);

    // 检查输入是否有效
    if (roomId.isEmpty() || type.isEmpty() || !sizeOk || !priceOk || status.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "所有字段都是必填的，请填写完整信息，并确保大小和价格是有效的数字。");
        return;
    }

    // 使用arg形式插入到数据库
    QSqlQuery query;
    QString queryString = QString("INSERT INTO room (rid, rtype, rsize, rprice, rstatus) "
                                  "VALUES ('%1', '%2', %3, %4, '%5')")
                              .arg(roomId)
                              .arg(type)
                              .arg(size)
                              .arg(price)
                              .arg(status);

    if (!query.exec(queryString)) {
        qDebug() << "Insert error:" << query.lastError().text();
        QMessageBox::critical(this, "数据库错误", "无法添加客房信息，请稍后再试。");
        return;
    }

    // 清空输入框
    ui->addRIdLineEdit->clear();
    ui->typeBox_2->setCurrentIndex(0);
    ui->addRsizeLineEdit->clear();
    ui->addRpriceLineEdit->clear();
    ui->statusBox_2->setCurrentIndex(0);

    QMessageBox::information(this, "成功", "客房信息添加成功。");
}


void Room::on_roomAddButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void Room::on_roomDeleteButton_clicked()
{
    // 获取房间号
    QString roomId = ui->roomidLineEdit->text();

    // 检查是否输入了房间号
    if (roomId.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "请提供房间号以删除客房信息。");
        return;
    }

    // 使用房间号删除客房信息
    QSqlQuery query;
    QString queryString = QString("DELETE FROM room WHERE rid = '%1'").arg(roomId);

    if (!query.exec(queryString)) {
        qDebug() << "Delete error:" << query.lastError().text();
        QMessageBox::critical(this, "数据库错误", "无法删除客房信息，请稍后再试。");
        return;
    }

    // 检查是否有其他输入字段
    QString type = ui->typeBox->currentText();
    QString leastPrice = ui->leastLineEdit->text();
    QString mostPrice = ui->mostLineEdit->text();
    QString status = ui->statusBox->currentText();

    if (!type.isEmpty() || !leastPrice.isEmpty() || !mostPrice.isEmpty() || !status.isEmpty()) {
        QMessageBox::information(this, "提示", "仅支持通过房间号删除，其他输入字段将被忽略。");
    }

    // 清空输入框
    ui->roomidLineEdit->clear();
    ui->typeBox->setCurrentIndex(0);
    ui->leastLineEdit->clear();
    ui->mostLineEdit->clear();
    ui->statusBox->setCurrentIndex(0);

    QMessageBox::information(this, "成功", "客房信息删除成功。");
}

