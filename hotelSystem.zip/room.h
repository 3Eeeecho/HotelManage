#ifndef ROOM_H
#define ROOM_H

#include <QWidget>
#include <QString>
#include <QSqlDatabase>
#include "hotel.h"

class Home;

namespace Ui {
class Room;
}

class Room : public QWidget
{
    Q_OBJECT

public:
    explicit Room(QWidget *parent = nullptr,Home *home=nullptr);
    void setInitialPage();
    ~Room();

signals:
    void backHome();

private slots:
    void on_roomInforButton_clicked();

    void on_roomselectButton_clicked();



    void on_addRoomButton_clicked();

    void on_roomAddButton_clicked();

    void on_roomDeleteButton_clicked();

private:
    Ui::Room *ui;
    Hotel hotel;
    Home *home;
};

#endif // ROOM_H
