#include "hotelsys.h"
#include <QMessageBox>

hotelsys::hotelsys(QObject *parent)
    : QObject(parent), loginUi(new Login)
{
    // 连接 loginUi 的信号到槽函数
    connect(loginUi, &QPushButton::clicked, this, &hotelsys::onLoginSuccess);

    // 显示登录界面
    loginUi->show();
}

hotelsys::~hotelsys()
{
    delete loginUi;
}

void hotelsys::onLoginSuccess()
{
    // 用户登录成功后执行的操作
    QMessageBox::information(nullptr, "Login Success", "You have successfully logged in!");

    // 在这里你可以执行其他操作，比如打开主界面，初始化系统等
}
