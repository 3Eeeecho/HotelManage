#ifndef ORDER_H
#define ORDER_H

#include <QWidget>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>

namespace Ui {
class Order;
}
struct booking
{
    quint16 m_bookingId;
    QString m_type;
    QString m_userId;
    QString m_roomId;
    QString m_startTime;
    QString m_endTime;
    QString m_bookingTime;
    QString m_registerId;
};

struct checkIn
{
    quint16 m_checkId;
    QString m_type;
    QString m_userId;
    QString m_roomId;
    QString m_startTime;
    QString m_endTime;
    double m_totalPrice;
    QString m_registerId;
};

struct order
{
    quint16 m_checkId;
    QString m_type;
    QString m_startTime;
    QString m_endTime;
    QString m_roomId;
    double m_totalPrice;
    QString m_orderTime;
    QString m_registerId;
};

class Order : public QWidget
{
    Q_OBJECT

public:
    explicit Order(QWidget *parent = nullptr);
    void setInitialPage();
    ~Order();

    //查询入住订单信息
    QList<checkIn> getCheckIn(quint16 orderid,QString roomid,QString cid);

    //删除入住订单
    void deleteCheckIn(quint16 orderid, QString roomid, QString cid);

    //查询预约订单信息
    QList<booking> getBooking(quint16 bookingid,QString roomid,QString cid);

    //删除预约订单
    void deleteBooking(quint16 bookingid, QString roomid, QString cid);

    //查询所有订单
    QList<order> getAll(quint16 allid,QString roomid);

    //删除所有订单
    void deleteAll(quint16 allid, QString roomid);


signals:
    void backHome();

private slots:
    void on_checkInButton_clicked();

    void on_checkselectButton_clicked();

    void on_checkdeleteButton_clicked();

    void on_bookingSelectButton_clicked();

    void on_bookingButton_clicked();

    void on_bookingDeleteButton_clicked();



    void on_allButton_clicked();

    void on_allSelectButton_clicked();

    void on_allDeleteButton_clicked();

private:
    Ui::Order *ui;
    QSqlDatabase db;
};

#endif // ORDER_H
