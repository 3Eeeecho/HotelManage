#ifndef STAFF_H
#define STAFF_H

#include <QWidget>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>

namespace Ui {
class Staff;
}

struct staff
{
    QString m_id;
    QString m_name;
    QString m_sex;
    QString m_username;
    QString m_password;
    QString m_role;
};

class Staff : public QWidget
{
    Q_OBJECT

public:
    explicit Staff(QWidget *parent = nullptr);
    void setInitialPage();
    QList<staff> getStaff(QString id,QString name,QString role);
    ~Staff();

signals:
    void backHome();

private slots:
    void on_selectStaffButton_clicked();

    void on_addStaffButton_clicked();

    void on_staffSelectButton_clicked();

    void on_staffDeleteButton_clicked();

    void on_staffAddButton_clicked();

private:
    Ui::Staff *ui;

    bool createSystemUser(const QString &username, const QString &password, const QString &role);
};

#endif // STAFF_H
