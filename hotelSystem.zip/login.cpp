#include "login.h"
#include "ui_login.h"


Login::Login(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Login)
    ,homeUi(nullptr)
{
    ui->setupUi(this);

    QObject::disconnect(ui->loginButton, nullptr, this, nullptr);
    QObject::disconnect(ui->aboutUsButton, nullptr, this, nullptr);

    //等待主页的退出登录信号
    connect(&homeUi,&Home::exit,this,[=,this](){
        homeUi.close();
        this->show();
    });

    // 连接 loginButton 的点击信号到槽函数
    connect(ui->loginButton, &QPushButton::clicked, this, &Login::on_loginButton_clicked);

    // 连接 aboutUsButton 的点击信号到槽函数
    connect(ui->aboutUsButton, &QPushButton::clicked, this, &Login::on_aboutUsButton_clicked);

    //一、新建action
    QAction* userAction = new QAction(ui->userLineEdit);
    QAction* passwordAction = new QAction(ui->pwLineEdit);
    //二、给action添加icon
    userAction->setIcon(QIcon(":/icon/user.png"));
    passwordAction->setIcon(QIcon(":icon/pw.png"));
    //三、给空间添加action
    ui->userLineEdit->addAction(userAction,QLineEdit::LeadingPosition);
    ui->pwLineEdit->addAction(passwordAction,QLineEdit::LeadingPosition);
}

Login::~Login()
{
    delete ui;
}

void Login::on_loginButton_clicked()
{
    QString user = ui->userLineEdit->text();
    QString pw = ui->pwLineEdit->text();

    // 创建数据库连接
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("localhost"); // 数据库主机名
    db.setPort(3306);
    db.setDatabaseName("HotelSystemplus"); // 数据库名称
    db.setUserName(user); // 数据库用户名
    db.setPassword(pw); // 数据库密码

    // 尝试连接数据库
    if (!db.open()) {
        QMessageBox::critical(this, "Database Connection Failed", db.lastError().text());
        qDebug() << "Database Connection Error: " << db.lastError().text();
        return;
    }
    else
    {
        // 在用户登录成功后调用
        homeUi.setUserRole(user); // 或 "user"，根据实际情况
        homeUi.show();
        this->close();
    }

    ui->userLineEdit->clear();
    ui->pwLineEdit->clear();
}


void Login::on_aboutUsButton_clicked()
{
    about.show();
}

