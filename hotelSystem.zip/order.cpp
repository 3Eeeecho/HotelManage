#include "order.h"
#include "ui_order.h"

Order::Order(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Order)
{
    ui->setupUi(this);

    QObject::disconnect(ui->allButton, nullptr, this, nullptr);
    QObject::disconnect(ui->allSelectButton, nullptr, this, nullptr);
    QObject::disconnect(ui->allDeleteButton, nullptr, this, nullptr);

    QObject::disconnect(ui->checkInButton, nullptr, this, nullptr);
    QObject::disconnect(ui->checkselectButton, nullptr, this, nullptr);
    QObject::disconnect(ui->checkdeleteButton, nullptr, this, nullptr);

    QObject::disconnect(ui->bookingButton, nullptr, this, nullptr);
    QObject::disconnect(ui->bookingSelectButton, nullptr, this, nullptr);
    QObject::disconnect(ui->bookingDeleteButton, nullptr, this, nullptr);

    //转到所有订单页面
    connect(ui->allButton,&QPushButton::clicked,this,&Order::on_allButton_clicked);
    //查询预约订单
    connect(ui->allSelectButton,&QPushButton::clicked,this,&Order::on_allSelectButton_clicked);
    //删除预约订单
    connect(ui->allDeleteButton,&QPushButton::clicked,this,&Order::on_allDeleteButton_clicked);

    //转到登记订单页面
    connect(ui->checkInButton,&QPushButton::clicked,this,&Order::on_checkInButton_clicked);
    //查询登记订单
    connect(ui->checkselectButton,&QPushButton::clicked,this,&Order::on_checkselectButton_clicked);
    //删除登记订单
    connect(ui->checkdeleteButton,&QPushButton::clicked,this,&Order::on_checkdeleteButton_clicked);

    //转到预约页面
    connect(ui->bookingButton,&QPushButton::clicked,this,&Order::on_bookingButton_clicked);
    //查询预约订单
    connect(ui->bookingSelectButton,&QPushButton::clicked,this,&Order::on_bookingSelectButton_clicked);
    //删除预约订单
    connect(ui->bookingDeleteButton,&QPushButton::clicked,this,&Order::on_bookingDeleteButton_clicked);

    // 连接返回按钮
    connect(ui->backHomeButton, &QPushButton::clicked, [=, this](){emit this->backHome();});
}

void Order::setInitialPage()
{
    ui->stackedWidget->setCurrentIndex(1);
}

Order::~Order()
{
    delete ui;
}

//查询登记订单
QList<checkIn> Order::getCheckIn(quint16 orderid,QString roomid,QString cid)
{
    QSqlQuery sql(db);
    QString queryString = "SELECT * FROM checkin WHERE 1=1";

    if (orderid != 0) {
        queryString += QString(" AND checkin_id = %1").arg(orderid);
    }

    if (!roomid.isEmpty()) {
        queryString += QString(" AND room_id = '%1'").arg(roomid);
    }

    if (!cid.isEmpty()) {
        queryString += QString(" AND client_or_team_id = '%1'").arg(cid);
    }

    qDebug() << "Constructed Query:" << queryString;
    sql.prepare(queryString);

    if (!sql.exec()) {
        qDebug() << "Query execution error:" << sql.lastError().text();
        return QList<checkIn>();
    }

    QList<checkIn> checkIns;
    while (sql.next()) {
        checkIn ci;
        ci.m_checkId = sql.value("checkin_id").toUInt();
        ci.m_type = sql.value("type").toString();
        ci.m_userId = sql.value("client_or_team_id").toString();
        ci.m_roomId = sql.value("room_id").toString();
        ci.m_startTime = sql.value("start_time").toString();
        ci.m_endTime = sql.value("end_time").toString();
        ci.m_totalPrice = sql.value("total_price").toDouble();
        ci.m_registerId = sql.value("check_in_sid").toString();
        checkIns.append(ci);
    }

    if (checkIns.isEmpty()) {
        qDebug() << "No results found.";
    }

    return checkIns;
}

// 删除登记订单
void Order::deleteCheckIn(quint16 orderid, QString roomid, QString cid)
{
    if (orderid == 0 && roomid.isEmpty() && cid.isEmpty()) {
        qDebug() << "No valid parameters provided for deletion.";
        return;
    }

    QSqlQuery sql(db);
    QString queryString = "DELETE FROM checkin WHERE 1=1";

    if (orderid != 0) {
        queryString += QString(" AND checkin_id = %1").arg(orderid);
    }

    if (!roomid.isEmpty()) {
        queryString += QString(" AND room_id = '%1'").arg(roomid);
    }

    if (!cid.isEmpty()) {
        queryString += QString(" AND client_or_team_id = '%1'").arg(cid);
    }

    qDebug() << "Constructed Query for deletion:" << queryString;
    sql.prepare(queryString);

    if (!sql.exec()) {
        qDebug() << "Query execution error:" << sql.lastError().text();
        return;
    }

    qDebug() << "Delete operation successful.";
}

//查询预约订单
QList<booking> Order::getBooking(quint16 bookingid,QString roomid,QString cid)
{
    QSqlQuery sql(db);
    QString queryString = "SELECT * FROM booking WHERE 1=1";

    if (bookingid != 0) {
        queryString += QString(" AND booking_id = %1").arg(bookingid);
    }

    if (!roomid.isEmpty()) {
        queryString += QString(" AND room_id = '%1'").arg(roomid);
    }

    if (!cid.isEmpty()) {
        queryString += QString(" AND client_or_team_id = '%1'").arg(cid);
    }

    qDebug() << "Constructed Query:" << queryString;
    sql.prepare(queryString);

    if (!sql.exec()) {
        qDebug() << "Query execution error:" << sql.lastError().text();
        return QList<booking>();
    }

    QList<booking> book;
    while (sql.next()) {
        booking ci;
        ci.m_bookingId = sql.value("booking_id").toUInt();
        ci.m_type = sql.value("type").toString();
        ci.m_userId = sql.value("client_or_team_id").toString();
        ci.m_roomId = sql.value("room_id").toString();
        ci.m_startTime = sql.value("start_time").toString();
        ci.m_endTime = sql.value("end_time").toString();
        ci.m_bookingTime = sql.value("booking_time").toString();
        ci.m_registerId = sql.value("register_sid").toString();
        book.append(ci);
    }

    if (book.isEmpty()) {
        qDebug() << "No results found.";
    }

    return book;
}

//删除预约订单
void Order::deleteBooking(quint16 bookingid, QString roomid, QString cid)
{
    if (bookingid == 0 && roomid.isEmpty() && cid.isEmpty()) {
        qDebug() << "No valid parameters provided for deletion.";
        return;
    }

    QSqlQuery sql(db);
    QString queryString = "DELETE FROM booking WHERE 1=1";

    if (bookingid != 0) {
        queryString += QString(" AND booking_id = %1").arg(bookingid);
    }

    if (!roomid.isEmpty()) {
        queryString += QString(" AND room_id = '%1'").arg(roomid);
    }

    if (!cid.isEmpty()) {
        queryString += QString(" AND client_or_team_id = '%1'").arg(cid);
    }

    qDebug() << "Constructed Query for deletion:" << queryString;
    sql.prepare(queryString);

    if (!sql.exec()) {
        qDebug() << "Query execution error:" << sql.lastError().text();
        return;
    }

    qDebug() << "Delete operation successful.";
}

//查询所有订单
QList<order> Order::getAll(quint16 allid,QString roomid)
{
    QSqlQuery sql(db);
    QString queryString = "SELECT * FROM hotelorder WHERE 1=1";

    if (allid != 0) {
        queryString += QString(" AND id = %1").arg(allid);
    }

    if (!roomid.isEmpty()) {
        queryString += QString(" AND rid = '%1'").arg(roomid);
    }

    qDebug() << "Constructed Query:" << queryString;
    sql.prepare(queryString);

    if (!sql.exec()) {
        qDebug() << "Query execution error:" << sql.lastError().text();
        return QList<order>();
    }

    QList<order> orders;
    while (sql.next()) {
        order o;
        o.m_checkId = sql.value("id").toUInt();
        o.m_type = sql.value("ordertype").toString();
        o.m_startTime = sql.value("start_time").toString();
        o.m_endTime = sql.value("end_time").toString();
        o.m_roomId = sql.value("rid").toString();
        o.m_totalPrice = sql.value("money").toDouble();
        o.m_orderTime = sql.value("order_time").toString();
        o.m_registerId = sql.value("register_sid").toString();
        orders.append(o);
    }

    if (orders.isEmpty()) {
        qDebug() << "No results found.";
    }

    return orders;
}

//删除所有订单
void Order::deleteAll(quint16 allid, QString roomid)
{
    if (allid == 0 && roomid.isEmpty() ) {
        qDebug() << "No valid parameters provided for deletion.";
        return;
    }

    QSqlQuery sql(db);
    QString queryString = "DELETE FROM hotelorder WHERE 1=1";

    if (allid != 0) {
        queryString += QString(" AND id = %1").arg(allid);
    }

    if (!roomid.isEmpty()) {
        queryString += QString(" AND rid = '%1'").arg(roomid);
    }

    qDebug() << "Constructed Query for deletion:" << queryString;
    sql.prepare(queryString);

    if (!sql.exec()) {
        qDebug() << "Query execution error:" << sql.lastError().text();
        return;
    }

    qDebug() << "Delete operation successful.";
}


void Order::on_checkselectButton_clicked()
{
    // 从输入框获取参数
    QString orderid = ui->checkidLineEdit->text();
    QString roomid = ui->checkridLineEdit->text();
    QString cid = ui->checkcidLineEdit->text();

    quint16 orderIdInt = orderid.isEmpty() ? 0 : orderid.toUInt();

    QList<checkIn> checkIns = getCheckIn(orderIdInt, roomid, cid);

    // 更新QTableWidget
    ui->checkinTableWidget->setRowCount(0); // 清空表格

    if (checkIns.isEmpty()) {
        int row = ui->checkinTableWidget->rowCount();
        ui->checkinTableWidget->insertRow(row);
        QTableWidgetItem *item = new QTableWidgetItem("未找到指定信息");
        item->setTextAlignment(Qt::AlignCenter);
        ui->checkinTableWidget->setItem(row, 0, item);
        ui->checkinTableWidget->setSpan(row, 0, 1, ui->checkinTableWidget->columnCount()); // 跨列显示
    } else {
        for (const checkIn &ci : checkIns) {
            int row = ui->checkinTableWidget->rowCount();
            ui->checkinTableWidget->insertRow(row);
            ui->checkinTableWidget->setItem(row, 0, new QTableWidgetItem(QString::number(ci.m_checkId)));
            ui->checkinTableWidget->setItem(row, 1, new QTableWidgetItem(ci.m_type));
            ui->checkinTableWidget->setItem(row, 2, new QTableWidgetItem(ci.m_userId));
            ui->checkinTableWidget->setItem(row, 3, new QTableWidgetItem(ci.m_roomId));
            ui->checkinTableWidget->setItem(row, 4, new QTableWidgetItem(ci.m_startTime));
            ui->checkinTableWidget->setItem(row, 5, new QTableWidgetItem(ci.m_endTime));
            ui->checkinTableWidget->setItem(row, 6, new QTableWidgetItem(QString::number(ci.m_totalPrice)));
            ui->checkinTableWidget->setItem(row, 7, new QTableWidgetItem(ci.m_registerId));
        }
    }
    if (checkIns.isEmpty()) {
        qDebug() << "No results found.";
    }
}


void Order::on_checkdeleteButton_clicked()
{
    quint16 checkId = ui->checkidLineEdit->text().toUShort();
    QString roomId = ui->checkridLineEdit->text();
    QString cid = ui->checkcidLineEdit->text();

    // 检查是否提供了至少一个有效参数
    if (checkId == 0 && roomId.isEmpty() && cid.isEmpty()) {
        QMessageBox::warning(this, "删除失败", "请提供至少一个有效的删除参数（登记订单号、房间号或客户/团队 ID）。");
        return;
    }

    // 提供弹窗，选择是否要删除还是取消
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "确认删除", "确定要删除这个登记订单吗？",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        deleteCheckIn(checkId, roomId, cid);
        // 提示删除成功
        QMessageBox::information(this, "删除成功", "登记订单删除成功。");
    } else {
        // 用户选择取消
        QMessageBox::information(this, "取消操作", "登记订单删除操作已取消。");
    }
}


void Order::on_checkInButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void Order::on_bookingSelectButton_clicked()
{
    // 从输入框获取参数
    QString bookid = ui->bookingIdLineEdit->text();
    QString roomid = ui->bookingRidLineEdit->text();
    QString cid = ui->bookingCidLineEdit->text();

    quint16 bookidInt = bookid.isEmpty() ? 0 : bookid.toUInt();

    QList<booking> books = getBooking(bookidInt, roomid, cid);

    // 更新QTableWidget
    ui->bookingTableWidget->setRowCount(0); // 清空表格

    if (books.isEmpty()) {
        int row = ui->bookingTableWidget->rowCount();
        ui->bookingTableWidget->insertRow(row);
        QTableWidgetItem *item = new QTableWidgetItem("未找到指定信息");
        item->setTextAlignment(Qt::AlignCenter);
        ui->bookingTableWidget->setItem(row, 0, item);
        ui->bookingTableWidget->setSpan(row, 0, 1, ui->bookingTableWidget->columnCount()); // 跨列显示
    } else {
        for (const booking &b : books) {
            int row = ui->bookingTableWidget->rowCount();
            ui->bookingTableWidget->insertRow(row);
            ui->bookingTableWidget->setItem(row, 0, new QTableWidgetItem(QString::number(b.m_bookingId)));
            ui->bookingTableWidget->setItem(row, 1, new QTableWidgetItem(b.m_type));
            ui->bookingTableWidget->setItem(row, 2, new QTableWidgetItem(b.m_userId));
            ui->bookingTableWidget->setItem(row, 3, new QTableWidgetItem(b.m_roomId));
            ui->bookingTableWidget->setItem(row, 4, new QTableWidgetItem(b.m_startTime));
            ui->bookingTableWidget->setItem(row, 5, new QTableWidgetItem(b.m_endTime));
            ui->bookingTableWidget->setItem(row, 6, new QTableWidgetItem(b.m_bookingTime));
            ui->bookingTableWidget->setItem(row, 7, new QTableWidgetItem(b.m_registerId));
        }
    }
}


void Order::on_bookingButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void Order::on_bookingDeleteButton_clicked()
{
    quint16 bookingId = ui->bookingIdLineEdit->text().toUShort();
    QString roomId = ui->bookingRidLineEdit->text();
    QString cid = ui->bookingCidLineEdit->text();

    // 检查是否提供了至少一个有效参数
    if (bookingId == 0 && roomId.isEmpty() && cid.isEmpty()) {
        QMessageBox::warning(this, "删除失败", "请提供至少一个有效的删除参数（预约订单号、房间号或客户/团队 ID）。");
        return;
    }

    // 提供弹窗，选择是否要删除还是取消
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "确认删除", "确定要删除这个预约订单吗？",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        deleteBooking(bookingId, roomId, cid);
        // 提示删除成功
        QMessageBox::information(this, "删除成功", "预约订单删除成功。");
    } else {
        // 用户选择取消
        QMessageBox::information(this, "取消操作", "预约订单删除操作已取消。");
    }
}


void Order::on_allButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void Order::on_allSelectButton_clicked()
{
    // 从输入框获取参数
    QString orderid = ui->allIdLineEdit->text();
    QString roomid = ui->allRidLineEdit->text();

    quint16 orderIdInt = orderid.isEmpty() ? 0 : orderid.toUInt();

    QList<order> orders = getAll(orderIdInt, roomid);

    // 更新QTableWidget
    ui->allTableWidget->setRowCount(0); // 清空表格

    for (const order &o : orders) {
        int row = ui->allTableWidget->rowCount();
        ui->allTableWidget->insertRow(row);
        ui->allTableWidget->setItem(row, 0, new QTableWidgetItem(QString::number(o.m_checkId)));
        ui->allTableWidget->setItem(row, 1, new QTableWidgetItem(o.m_type));
        ui->allTableWidget->setItem(row, 2, new QTableWidgetItem(o.m_startTime));
        ui->allTableWidget->setItem(row, 3, new QTableWidgetItem(o.m_endTime));
        ui->allTableWidget->setItem(row, 4, new QTableWidgetItem(o.m_roomId));
        ui->allTableWidget->setItem(row, 5, new QTableWidgetItem(QString::number(o.m_totalPrice)));
        ui->allTableWidget->setItem(row, 6, new QTableWidgetItem(o.m_orderTime));
        ui->allTableWidget->setItem(row, 7, new QTableWidgetItem(o.m_registerId));
    }

    if (orders.isEmpty()) {
        qDebug() << "No results found.";
    }
}


void Order::on_allDeleteButton_clicked()
{
    quint16 bookingId = ui->allIdLineEdit->text().toUShort();
    QString roomId = ui->allRidLineEdit->text();

    // 检查是否提供了至少一个有效参数
    if (bookingId == 0 && roomId.isEmpty()) {
        QMessageBox::warning(this, "删除失败", "请提供至少一个有效的删除参数（订单号、房间号。");
        return;
    }

    // 提供弹窗，选择是否要删除还是取消
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "确认删除", "确定要删除这个订单吗？",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        deleteAll(bookingId, roomId);
        // 提示删除成功
        QMessageBox::information(this, "删除成功", "订单删除成功。");
    } else {
        // 用户选择取消
        QMessageBox::information(this, "取消操作", "订单删除操作已取消。");
    }
}

