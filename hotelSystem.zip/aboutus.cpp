#include "aboutus.h"
#include "ui_aboutus.h"

AboutUs::AboutUs(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::AboutUs)
{
    ui->setupUi(this);

    // 将 QLabel 的文本设置为 HTML 格式的超链接
    ui->csdnLabel->setText("<a href=\"https://blog.csdn.net/qq_45640453/article/details/139351028\">点击这里访问CSDN</a>");

    // 允许 QLabel 打开外部链接
    ui->csdnLabel->setOpenExternalLinks(true);


    ui->githubLabel->setText("<a href=\"https://github.com/3Eeeecho?tab=repositories\">点击这里访问GitHub</a>");


    ui->githubLabel->setOpenExternalLinks(true);


}

AboutUs::~AboutUs()
{
    delete ui;
}
