#ifndef CUSTOM_H
#define CUSTOM_H

#include <QWidget>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>

namespace Ui {
class Custom;
}

struct individual
{
    QString m_name;
    QString m_id;
    QString m_phone;
    QString m_age;
    QString m_sex;
    QString m_registerId;
    QString m_registerTime;
};

struct team
{
    QString m_name;
    QString m_id;
    QString m_phone;
    QString m_registerId;
    QString m_registerTime;
};

class Custom : public QWidget
{
    Q_OBJECT

public:
    explicit Custom(QWidget *parent = nullptr);
    QList<individual> getIndividual(QString name,QString id,QString phone);
    QList<team> getTeam(QString name, QString id,QString phone);
    void setInitialPage();
    ~Custom();

signals:
    void backHome();
private slots:
    void on_SelectButton_clicked();

    void on_addIndividualButton_clicked();

    void on_customAddButton_clicked();

    void on_DeleteButton_clicked();

    void on_addTeamButton_clicked();

    void on_teamAddButton_clicked();

    void on_customManageButton_clicked();

private:
    Ui::Custom *ui;
};

#endif // CUSTOM_H
